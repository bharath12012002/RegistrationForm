export const baseURL = () => {
  return localStorage.getItem("TGZ_api_url")
};
